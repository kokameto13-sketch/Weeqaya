package com.weeqaya.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.util.UUID

data class Maintenance(val id:String,val month:String,val control:String,val bar:String,val distributor:String,val before:Int=0,val after:Int=0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { Weeqaya() } }
    @Composable fun Weeqaya() {
        var tab by remember { mutableStateOf(0) }
        var records by remember { mutableStateOf(listOf<Maintenance>()) }
        Scaffold(topBar={TopAppBar(title={Text("وقاية - أعمال الصيانة")})}, bottomBar={
            NavigationBar {
                NavigationBarItem(tab==0,{tab=0},{Icon(Icons.Default.AddAPhoto,null)},label={Text("صيانة")})
                NavigationBarItem(tab==1,{tab=1},{Icon(Icons.Default.Search,null)},label={Text("بحث")})
                NavigationBarItem(tab==2,{tab=2},{Icon(Icons.Default.Cloud,null)},label={Text("Drive")})
            }
        }) { p -> when(tab){0->NewMaintenance(p){records=records+it};1->SearchScreen(p,records);2->DriveScreen(p)} }
    }
    @Composable fun NewMaintenance(p:PaddingValues,onSave:(Maintenance)->Unit){
        val c=LocalContext.current
        var month by remember{mutableStateOf("")}; var control by remember{mutableStateOf("")}; var bar by remember{mutableStateOf("")}; var dist by remember{mutableStateOf("")}
        var before by remember{mutableIntStateOf(0)}; var after by remember{mutableIntStateOf(0)}; var phase by remember{mutableStateOf(0)}
        val camera=rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()){ if(it!=null){if(phase==0)before++ else after++} }
        val perm=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){if(it)camera.launch(null)}
        fun take(){if(ContextCompat.checkSelfPermission(c,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)camera.launch(null) else perm.launch(Manifest.permission.CAMERA)}
        LazyColumn(Modifier.padding(p).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            item{Text("عملية صيانة جديدة",style=MaterialTheme.typography.headlineSmall)}
            item{OutlinedTextField(month,{month=it},label={Text("شهر الصيانة")},modifier=Modifier.fillMaxWidth())}
            item{OutlinedTextField(control,{control=it},label={Text("اسم وحدة التحكم")},modifier=Modifier.fillMaxWidth())}
            item{OutlinedTextField(bar,{bar=it},label={Text("البار")},modifier=Modifier.fillMaxWidth())}
            item{OutlinedTextField(dist,{dist=it},label={Text("اسم الموزع")},modifier=Modifier.fillMaxWidth())}
            item{PhotoCard("قبل الصيانة",before){phase=0;take()}}
            item{PhotoCard("بعد الصيانة",after){phase=1;take()}}
            item{Button(enabled=month.isNotBlank()&&control.isNotBlank()&&bar.isNotBlank()&&dist.isNotBlank(),onClick={onSave(Maintenance(UUID.randomUUID().toString(),month,control,bar,dist,before,after));Toast.makeText(c,"تم حفظ العملية",Toast.LENGTH_SHORT).show()},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Save,null);Spacer(Modifier.width(8.dp));Text("حفظ عملية الصيانة")}}
        }
    }
    @Composable fun PhotoCard(t:String,n:Int,click:()->Unit){Card(Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp),horizontalArrangement=Arrangement.SpaceBetween){Column(Modifier.weight(1f)){Text(t,style=MaterialTheme.typography.titleMedium);Text("عدد الصور: $n")}Button(onClick=click){Text("تصوير")}}}}
    @Composable fun SearchScreen(p:PaddingValues,rs:List<Maintenance>){var q by remember{mutableStateOf("")};val f=rs.filter{listOf(it.month,it.control,it.bar,it.distributor).any{v->v.contains(q,true)}};LazyColumn(Modifier.padding(p).padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){item{OutlinedTextField(q,{q=it},label={Text("بحث")},modifier=Modifier.fillMaxWidth())};items(f){r->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text("${r.control} - ${r.bar}");Text("${r.month} | ${r.distributor}");Text("قبل: ${r.before} | بعد: ${r.after}")}}}}}
    @Composable fun DriveScreen(p:PaddingValues){Column(Modifier.padding(p).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Google Drive",style=MaterialTheme.typography.headlineSmall);Text("هذه الشاشة جاهزة لربط التخزين المركزي. إعداد OAuth يتم خارج الكود ولا يتم وضع كلمة مرور أو Token داخل التطبيق.");Button(onClick={}){Text("إعداد Drive")};Text("هيكل التخزين المقترح: Weeqaya / السنة / الشهر / عملية الصيانة / قبل و بعد")}}
}
